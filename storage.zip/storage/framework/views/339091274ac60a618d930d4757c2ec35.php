<nav id="main-nav">
    <ul class="nav-menu sm-horizontal theme-scrollbar" id="sm-horizontal">
        <li class="mobile-back" id="mobile-back">Trở lại<i class="fa-solid fa-angle-right ps-2" aria-hidden="true"></i></li>
        <!-- Mục Sản phẩm (Bộ sưu tập) -->
        <li>
            <a class="nav-link" href="#">Bộ sưu tập<span><i
                        class="fa-solid fa-angle-down"></i></span></a>
            <ul class="nav-submenu">
                <li><a href="#">Gọng cận</a></li>
                <li><a href="#">Gọng Lão đọc báo</a></li>
                <li><a href="#">Gọng trẻ em</a></li>
                <li><a href="#"> Gọng trợ giá ƯU ĐÃI</a></li>
            </ul>
        </li>
        <li><a class="nav-link" href="<?php echo e(url('san-pham')); ?>">Sản phẩm</a></li>

        <!-- Mục Dịch Vụ -->
        <li><a class="nav-link" href="#">Dịch vụ tròng</a></li>

        <!-- Mục Về Chúng Tôi -->
        <li><a class="nav-link" href="<?php echo e(url('gioi-thieu')); ?>">Về chúng tôi</a></li>
        <ul class="social-media-menu">
            <li class="social facebook">
                <a target="_blank" rel="nofollow noopener noreferrer"
                    href="https://www.facebook.com/matkinhthuocbvdienbienphu"
                    class="social-link">
                    <i class="fab fa-facebook-f"></i>
                </a>
            </li>
            <li class="social zalo">
                <a target="_blank" rel="nofollow noopener noreferrer"
                    href="https://zalo.me/0338596789" class="social-link">
                    <img src="https://media.metu.vn/fillcolor?url=https%3A%2F%2Fmedia.metu.vn%2Fimages%2Ficon_zalo_01.svg&amp;color=%23ffffff"
                        alt="Zalo" width="16" height="16">
                </a>
            </li>
            <li class="social youtube">
                <a target="_blank" rel="nofollow noopener noreferrer"
                    href="https://www.youtube.com/channel/UCyB0SC9E_DZqn03_uzj5yrQ"
                    class="social-link">
                    <i class="fab fa-youtube"></i>
                </a>
            </li>
            <li class="social hotline">
                <a href="tel:0338596789" class="hotline-link">
                    <i class="fas fa-phone-alt"></i> Hotline: <span
                        class="hotline-number">0338596789</span>
                </a>
            </li>

        </ul>
        <style>
            .social-media-menu {
                list-style-type: none;
                padding: 0;
                margin: 0;
                display: flex;
                gap: 20px;
                /* Space between icons */
                justify-content: center;
                /* Center the icons horizontally */
            }

            .social {
                display: flex;
                align-items: center;
                text-align: center;
            }

            .social-link {
                display: flex;
                align-items: center;
                text-decoration: none;
                background: rgb(97, 147, 255);
                padding: .2rem;
                border-radius: 100%;
                display: flex;
                width: 25px;
                justify-content: center;
                display: flex;
                height: 25px;
                color: inherit;
                font-size: 16px;
                /* Adjust size as needed */
            }

            .social-link i {
                font-size: 16px;
                /* Icon size */
            }

            .social-link img {
                vertical-align: middle;
            }

            .social-text {
                font-size: 16px;
                /* Text size */
            }

            .facebook .social-link {
                color: #3b5998;
                /* Facebook color */
            }

            .zalo .social-link {
                color: #0076ff;
                /* Zalo color */
            }

            .youtube .social-link {
                color: #ff0000;
                /* YouTube color */
            }

            .facebook .social-link:hover,
            .zalo .social-link:hover,
            .youtube .social-link:hover {
                opacity: 0.7;
                /* Slight opacity on hover */
            }
        </style>
    </ul>
</nav>
<?php /**PATH D:\ana (1)\resources\views/livewire/partials/navbar.blade.php ENDPATH**/ ?>