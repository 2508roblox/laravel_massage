<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="SHORTCUT ICON" href="/favicon.ico" />
    <link rel="canonical" href="./" />
    <link rel="stylesheet" type="text/css" href="<?php echo e('assets/css/vendors/fontawesome.css'); ?>"><!-- Iconsax icon-->
    <link rel="stylesheet" type="text/css" href="<?php echo e('assets/css/vendors/iconsax.css'); ?>"><!-- Bootstrap css-->
    <link rel="stylesheet" type="text/css" id="rtl-link" href="<?php echo e('assets/css/vendors/bootstrap.css'); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e('assets/css/vendors/swiper-slider/swiper-bundle.min.css'); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e('assets/css/vendors/toastify.css'); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e('assets/css/style.css'); ?>">
    <script defer src="<?php echo e(asset('assets/css/landing_page.js')); ?>"></script>
    <script defer src="<?php echo e(asset('assets/css/style.js')); ?>"></script>
    <link href="<?php echo e('assets/css/landing_page.css'); ?>" rel="stylesheet">
    <link href="<?php echo e('assets/css/style.css'); ?>" rel="stylesheet">
    <meta name="google-site-verification" content="9C_LcN2Q3W52t20KfsaL3LT6mCB06uGMwUB8N8pfrT8" />
    
        <!-- Google Font Outfit -->
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin="">
        <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@100..900&amp;display=swap" rel="stylesheet">

        <!-- Font Awesome -->
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/vendors/fontawesome.css')); ?>">

        <!-- Iconsax icon -->
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/vendors/iconsax.css')); ?>">

        <!-- Bootstrap CSS -->
        <link rel="stylesheet" type="text/css" id="rtl-link" href="<?php echo e(asset('assets/css/vendors/bootstrap.css')); ?>">

        <!-- Additional CSS -->
        <link rel="stylesheet" type="text/css"
            href="<?php echo e(asset('assets/css/vendors/swiper-slider/swiper-bundle.min.css')); ?>">
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/vendors/toastify.css')); ?>">
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/style.css')); ?>">

        <!-- JS -->
        <script defer src="<?php echo e(asset('assets/css/landing_page.js')); ?>"></script>
        <script defer src="<?php echo e(asset('assets/css/style.js')); ?>"></script>
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link
            href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&display=swap"
            rel="stylesheet">
        <style>
            .product-box-3 .img-wrapper .product-image {
                background-color: white !important;
            }

            .pro-first.bg-size {
                background-size: contain !important;
            }

            *,
            body,
            h1,
            h2,
            h3,
            h4,
            h5,
            h6 {
                font-family: 'Roboto';
            }
        </style>
        <style>
            @import url('https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&display=swap');
        </style>
    <?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::styles(); ?>

</head>

<body>
    <?php echo e($slot); ?>

    <?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::scripts(); ?>

    <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>

   
</body>
<style>
    @media (max-width: 992px) {
        .col-md-9 {
            width: 100%;
        }
    }

    @media (max-width: 992px) {
        .col-sm-3 {
            width: 100%;
        }
    }
    .tap-top.top {
    display: block;
    /* bottom: 7rem; */
    left: 40px;
    transition: all .5s ease;
}
</style>
<?php if (isset($component)) { $__componentOriginal8344cca362e924d63cb0780eb5ae3ae6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8344cca362e924d63cb0780eb5ae3ae6 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'livewire-alert::components.scripts','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('livewire-alert::scripts'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8344cca362e924d63cb0780eb5ae3ae6)): ?>
<?php $attributes = $__attributesOriginal8344cca362e924d63cb0780eb5ae3ae6; ?>
<?php unset($__attributesOriginal8344cca362e924d63cb0780eb5ae3ae6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8344cca362e924d63cb0780eb5ae3ae6)): ?>
<?php $component = $__componentOriginal8344cca362e924d63cb0780eb5ae3ae6; ?>
<?php unset($__componentOriginal8344cca362e924d63cb0780eb5ae3ae6); ?>
<?php endif; ?>

</html>
<?php /**PATH /home/u601799998/domains/drmkey.vn/resources/views/components/layouts/app.blade.php ENDPATH**/ ?>