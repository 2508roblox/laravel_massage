      <header style="
            position: sticky;
            top: 0;
            background: white;
            z-index: 100;
        ">

                <div class="custom-container container header-1">
                    <div class="row">
                        <div class="col-12 p-0">
                            <div class="mobile-fix-option">
                                <ul>
                                    <li> <a href="<?php echo e(url('/')); ?>"><i class="iconsax" data-icon="home-1"></i>Trang chủ</a>
                                    </li>
                                    <li><a href="<?php echo e(url('/san-pham')); ?>"><i class="iconsax"
                                                data-icon="search-normal-2"></i>Tìm kiếm</a></li>
                                    <li><a href="<?php echo e(url('/gio-hang')); ?>"><i class="iconsax"
                                                data-icon="shopping-cart"></i>Giỏ hàng</a></li>
                                </ul>
                            </div>
                            <div class="offcanvas offcanvas-start" id="staticBackdrop" data-bs-backdrop="static"
                                tabindex="-1" aria-labelledby="staticBackdropLabel">
                                <div class="offcanvas-header">
                                    <h3 class="offcanvas-title" id="staticBackdropLabel">Offcanvas</h3><button
                                        class="btn-close" type="button" data-bs-dismiss="offcanvas"
                                        aria-label="Close"></button>
                                </div>
                                <div class="offcanvas-body">
                                    <div></div>I will not close if you click outside of me.
                                </div>
                            </div>
                        </div>
                        <div class="col-12">
                            <div class="main-menu"> <a class="brand-logo" href="<?php echo e(url('/')); ?>"> <img
                                        class="img-fluid for-light" src="<?php echo e(asset('assets/images/logo.svg')); ?>"
                                        alt="logo" /><img class="img-fluid for-dark"
                                        src="<?php echo e(asset('assets/images/logo.svg')); ?>" alt="logo" /></a>
                                <nav id="main-nav">

                                    <ul class="nav-menu sm-horizontal theme-scrollbar" id="sm-horizontal">
                                        <li class="mobile-back" id="mobile-back">Trở lại<i
                                                class="fa-solid fa-angle-right ps-2" aria-hidden="true"></i></li>

                                        <!-- Mục Sản phẩm (Bộ sưu tập) -->
                                        <li>
                                            <a class="nav-link" href="#">Bộ sưu tập <span><i
                                                        class="fa-solid fa-angle-down"></i></span></a>
                                            <ul class="nav-submenu">
                                                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li>
                                                    <a href="<?php echo e(url('category/'.$category->slug)); ?>">
                                                        <?php echo e($category->name); ?>

                                                    </a>
                                                </li>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                            </ul>
                                        </li>

                                        <li><a class="nav-link" href="<?php echo e(url('san-pham')); ?>">Sản phẩm</a></li>

                                        <!-- Mục Dịch Vụ -->
                                        <li><a class="nav-link" href="#">Dịch vụ tròng</a></li>

                                        <!-- Mục Về Chúng Tôi -->
                                        <li><a class="nav-link" href="<?php echo e(url('gioi-thieu')); ?>">Về chúng tôi</a></li>
                                        <li class="nav-item" style="display: flex;align-items: center;">
                                            <a class="nav-item-highlight" href="<?php echo e(url('gioi-thieu')); ?>">ĐÀO TẠO NGHỀ
                                                MẮT KÍNH</a>
                                        </li>
                                        <style>
                                            .nav-item-highlight {
                                                text-transform: uppercase;
                                                background-image: linear-gradient(-225deg,
                                                        #231557 0%,
                                                        #44107a 29%,
                                                        #ff1361 67%,
                                                        #fff800 100%);
                                                background-size: auto auto;
                                                background-clip: border-box;
                                                background-size: 200% auto;
                                                color: #fff;
                                                background-clip: text;
                                                text-fill-color: transparent;
                                                -webkit-background-clip: text;
                                                -webkit-text-fill-color: transparent;
                                                animation: textclip 2s linear infinite;
                                                display: inline-block;
                                                font-size: 16px;
                                            }

                                            .hotline-number .phone-part {
                                                margin-right: 2px;
                                                /* Điều chỉnh khoảng cách giữa các phần số */
                                            }

                                            @keyframes textclip {
                                                to {
                                                    background-position: 200% center;
                                                }
                                            }
                                        </style>


                                        <style>
                                            .social-media-menu {
                                                list-style-type: none;
                                                padding: 0;
                                                margin: 0;
                                                display: flex;

                                                /* Space between icons */
                                                justify-content: center;
                                                /* Center the icons horizontally */
                                            }

                                            .social {
                                                display: flex;
                                                align-items: center;
                                                text-align: center;
                                            }

                                            .social-link {
                                                display: flex;
                                                align-items: center;
                                                text-decoration: none;
                                                background: rgb(97, 147, 255);
                                                padding: .2rem;
                                                border-radius: 100%;
                                                display: flex;
                                                width: 25px;
                                                justify-content: center;
                                                display: flex;
                                                height: 25px;
                                                color: inherit;
                                                font-size: 16px;
                                                /* Adjust size as needed */
                                            }

                                            .social-link i {
                                                font-size: 16px;
                                                /* Icon size */
                                            }

                                            .social-link img {
                                                vertical-align: middle;
                                            }

                                            .social-text {
                                                font-size: 16px;
                                                /* Text size */
                                            }

                                            .facebook .social-link {
                                                color: #3b5998;
                                                /* Facebook color */
                                            }

                                            .zalo .social-link {
                                                color: #0076ff;
                                                /* Zalo color */
                                            }

                                            .youtube .social-link {
                                                color: #ff0000;
                                                /* YouTube color */
                                            }

                                            .facebook .social-link:hover,
                                            .zalo .social-link:hover,
                                            .youtube .social-link:hover {
                                                opacity: 0.7;
                                                /* Slight opacity on hover */
                                            }
                                        </style>
                                    </ul>
                                </nav>
                                <style>
                                    #main-nav li a {
                                        font-weight: bold;
                                        text-transform: uppercase;
                                    }
                                </style>
                                <div class="sub_header">
                                    <div class="toggle-nav" id="toggle-nav">
                                        <i class="fa-solid fa-bars-staggered sidebar-bar"></i>
                                    </div>
                                    <ul class="justify-content-end">
                                        <li class="onhover-div">
                                            <a href="#"></a>
                                            <div class="onhover-show-div user">
                                                <ul>
                                                    <li><a href="login.html">Login</a></li>
                                                    <li><a href="sign-up.html">Register</a></li>
                                                </ul>
                                            </div>
                                        </li>
                                        <li>
                                            <a href="/bao-hanh" title="Tra cứu đơn hàng" wire:navigate>
                                                <i class="iconsax" data-icon="search-normal-2"></i> Tra cứu đơn hàng
                                            </a>
                                        </li>
                                        <li class="onhover-div shopping-cart">
                                            <a class="p-0" href="#" data-bs-toggle="offcanvas"
                                                data-bs-target="#offcanvasRight" aria-controls="offcanvasRight">
                                                <a href="/gio-hang" title="Xem giỏ hàng" wire:navigate>
                                                    <i class="iconsax pe-2" data-icon="basket-2"></i> Giỏ hàng
                                                </a>
                                            </a>
                                        </li>
                                        <!-- New Order Tracking Icon -->

                                    </ul>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </header><?php /**PATH /home/u601799998/domains/drmkey.vn/resources/views/livewire/partials/header.blade.php ENDPATH**/ ?>