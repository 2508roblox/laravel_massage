<p
    <?php echo e($attributes->class(['fi-global-search-no-results-message px-4 py-4 text-sm text-gray-500 dark:text-gray-400'])); ?>

>
    <?php echo e(__('filament-panels::global-search.no_results_message')); ?>

</p>
<?php /**PATH /home/u601799998/domains/drmkey.vn/vendor/filament/filament/src/../resources/views/components/global-search/no-results-message.blade.php ENDPATH**/ ?>